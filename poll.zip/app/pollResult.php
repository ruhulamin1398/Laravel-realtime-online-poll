<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pollResult extends Model
{
    //
}
